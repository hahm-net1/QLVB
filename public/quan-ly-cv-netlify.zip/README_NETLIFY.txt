HUONG DAN DEPLOY APP QUAN LY CV LEN NETLIFY
============================================

Cach 1: Netlify Drop (Nhanh nhat - khong can build):
1. Truy cap https://app.netlify.com/drop
2. Dang nhap hoac tao tai khoan Netlify mien phi.
3. Keo tha truc tiep file ZIP nay vao o "Drag and drop your site output folder here".
4. Website se duoc publish truc tuyen trong vai giay!
